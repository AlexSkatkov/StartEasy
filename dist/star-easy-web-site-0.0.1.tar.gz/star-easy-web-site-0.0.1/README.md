# Example Package

project Django
[Github](https://github.com/AlexSkatkov/StartEasy)
web site